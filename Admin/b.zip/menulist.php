</br></br></br>
<div class="col-sm-12">
</br>
				
                        <header class="panel-heading">
                           Menu List
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form">
                                <div class="form-group">
                                    
							
								
								
								<div class="form-group">
                                    <label for="">Food Id</label>
									<input type="text" class="form-control" id="" placeholder="">

                                </div>
								
								<div class="form-group">
                                    <label for="">Food Name</label>
									<input type="text" class="form-control" id="" placeholder="">

                                </div>
								<div class="form-group">
                                    <label for="">Food Category</label>
									 <Select class="form-control" id="">
									 <option value="" select>BreakFast</option>
									<option value="" select>Snacks</option>
								<option value="" select>Lunch</option>
									</select>
                                </div>
								
								<div class="form-group">
                                    <label for="">Food Quantity</label>
									 <Select class="form-control" id="">
									<option value="" select>Half Quantity</option>
									<option value="">Full Quantity</option>
									</select>
                                </div>
							
								<div class="form-group">
                                    <label for="">Food Price</label>
									<input type="text" class="form-control" id="" placeholder="">

                                </div>
								
							
								
							

                                <button type="submit" class="btn btn-info">Submit</button>
                            </form>
                            </div>

                        </div>
<div class="table-agile-info">
<div class="panel panel-default">

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <thead>
          <tr>
           
						<th>Food_id</th>
			            <th>Food_Name</th>
			            <th>Food_Category</th>
						<th>Food_Quantity</th>

			            <th>Food_Price</th>






			           

			<th>Action</th>

          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
            <td>1</td>
            
						
			            <td>Dosa</td>
					  <td>Snacks</td>

			            <td>3</td>
			            <td>Rs.25/-</td>

            

  
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-edit'></td>
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-remove'></td>
          
    </div>
    <footer class="panel-footer">
      <div class="row">
        
        <div class="col-sm-7 text-right text-center-xs">                
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <li><a href=""><i class="fa fa-chevron-left"></i></a></li>
            <li><a href="">1</a></li>
            <li><a href="">2</a></li>
            <li><a href="">3</a></li>
            <li><a href="">4</a></li>
            <li><a href=""><i class="fa fa-chevron-right"></i></a></li>
          </ul>
        </div>
      </div>
    </footer>


            </div>
        </div>
</div>		


