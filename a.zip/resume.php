<br><br>
<div class="table-agile-info">
<div class="panel panel-default">

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <thead>
          <tr>
            <th data-breakpoints="xs">ID</th>
			            <th>Student_Name</th>
						<th>class</th>
			            <th>branch</th>
			            <th>college_Name</th>
			            <th>avg_marks</th>






			           

			<th>Action</th>

          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
            <td>1</td>
            <td>abc</td>
            <td>BE-C</td>
			            <td>Computer Engineering</td>
						
			            <td>DYPCET</td>
			            <td>68</td>

            

  
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-edit'></td>
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-remove'></td>
          
    </div>
	
   

            </div>
        </div>
</div>		