</br></br></br>
<div class="col-sm-12">

</br>
				
                        <header class="panel-heading">
						<h3>Aptitude-Beginner</h3>
							</header>		


<div class="table-agile-info">



<p><h3>Description</h3></p>
<div class="panel panel-default" id="mydiv"><div class="">

This practice test will allow you to measure your Quantitative skills at the beginner level by the way of various multiple choice questions. We recommend you to score atleast 75% in this test before moving to the next level questionnaire. It will help you in identifying your strength and development areas. Based on the same you can plan your next steps in learning Quantitative Skills and preparing for job placements. #Aptitude #Quantitative #MCQ #Beginner
	  
<div style="text-align: right;">
</div>
	  
</div></div></div></div><br><br>


<p><h3>Instuctuions</h3></p>
<div class="panel panel-default" id="mydiv"><div class="">

1. This Practice Test consists of only MCQ questions.</br>

2. There are a total of 30 questions. Test Duration is 30 minutes.</br>

3. There is Negative Marking for wrong answers.</br>

4. Do Not switch tabs while taking the test. Switching Tabs will Block / End the test automatically.</br>

5. The test will only run in full screen mode. Do not switch back to tab mode. Test will end automatically.</br>

6. You may need to use blank sheets for rough work. Please arrange for blank sheets before starting.</br>

7. Clicking on Back or Next will save the answer</br>

8. Questions can be reattempted till the time test is running.</br>

9. Click on the finish test once you are done with the test.</br>

10. You will be able to view the scores once your test is complete.	</br>  </br>

<input type="checkbox">I certify that i have read all the instruction carefully
<div style="text-align: right;">
</div>
	  
</div></div><br><br>


   <button class="mybtn" type="submit" >Start Test</button><br>







	  
	  
        </div>
</div>		

<style>
#mydiv
{
padding-left: 15px;
padding-right: 15px;
padding-top: 10px;
padding-bottom: 10px;
box-shadow: 0 0.1875rem 1.25rem rgba(0, 0, 0, 0.16);
margin-bottom: 0.625rem;
border-radius: 30px;
font-size:90%;
}

#myimg
{
	width:80px;
	height:80px;
	background: #0000ff;
	border-radius: 80%;
	float:left;
	margin-right: 0.625rem;
}

#mybutton
{
color: rgba(0, 0, 0, 0.87);
    border: none;
    cursor: default;
    height: 32px;
    display: inline-flex;
    outline: none;
    padding: 10px;
	margin-right: 10px;
    font-size: 0.8125rem;
    box-sizing: border-box;
    transition: background-color 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
    align-items: center;
    font-family: SF Pro Display,"Helvetica Neue",Arial,sans-serif;
    white-space: nowrap;
    border-radius: 16px;
    vertical-align: middle;
    justify-content: center;
    text-decoration: none;
    background-color: #e0e0e0;
	font-size:70%;
}	
.mybtn {
	float:right;
	font-size:20px;
	margin-right:10px;
    height:40px;
    border:none;
    background:#00a6b2;
    color:#fff;
    padding:0px 50px;
    border-radius:4px;
    -webkit-border-radius:0 4px 4px 0;
}

</style>