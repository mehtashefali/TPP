
<!DOCTYPE html>
<head>
<title>Visitors an Admin Panel Category Bootstrap Responsive Website Template | Home :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="css/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
</head>
<body id="bodymystyle">
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">


 
  
</div>

<!--logo end-->
<div class="nav notify-row" id="top_menu">
    <!--  notification start -->
    <ul class="nav top-menu">
        <!-- settings start -->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <i class="fa fa-tasks"></i>
                <span class="badge bg-success"></span>
            </a>
            <ul class="dropdown-menu extended tasks-bar">
                <li>
                    <p class="">You have  pending tasks</p>
                </li>
                
                

                <li class="external">
                    <a href="#">See All Tasks</a>
                </li>
            </ul>
        </li>
        <!-- settings end -->
        <!-- inbox dropdown start-->
        <li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <i class="fa fa-comment"></i>
                <span class="badge bg-important"></span>
            </a>
            <ul class="dropdown-menu extended inbox">
                <li>
                    <p class="red">You have  Messages</p>
                </li>
                <li>
                    
                <li>
                    <a href="#">See all messages</a>
                </li>
            </ul>
        </li>
		<li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <i class="fa fa-book"></i>
                <span class="badge bg-important"></span>
            </a>
            <ul class="dropdown-menu extended inbox">
               
                <li>
                    
                
            </ul>
        </li>
		<li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <i class="fa fa-calendar"></i>
                <span class="badge bg-important"></span>
            </a>
            <ul class="dropdown-menu extended inbox">
                <li>
                    <p class="red"></p>
                </li>
                <li>
                    
                <li>
                    <a href="#"></a>
                </li>
            </ul>
        </li>
        <!-- inbox dropdown end -->
        <!-- notification dropdown start-->
        <li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                <i class="fa fa-bell"></i>
                <span class="badge bg-warning"></span>
            </a>
            <ul class="dropdown-menu extended notification">
                <li>
                    <p>Notifications</p>
                </li>
               
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <li>
            <input type="text" class="form-control search" placeholder=" Search">
        </li>
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src="images/s.jpg">
                <span class="username">Shefali Mehta</span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
                <li><a href="#"><i class=" fa fa-suitcase"></i>Profile</a></li>
                <li><a href="#"><i class="fa fa-cog"></i> Settings</a></li>
				<li><a href="plcecon.jsp"><i class="fa fa-key"></i> Placement Console</a></li>
				<li><a href="#"><i class="fa fa-key"></i> Manage As Admin</a></li>
				<li><a href="login.html"><i class="fa fa-key"></i> Log Out</a></li>

            </ul>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<br><br><br><br><br>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<div class="container">
    	<div class="row">
        <div class="col-md-16">
          <p>
            <a href="events.jsp" class="btn btn-sq btn-primary">
                <i class="fa fa-user fa-5x"></i><br><br>
                Placement Event<br>Add,Edit and Manage Placement Event
            </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="students.jsp" class="btn btn-sq btn-primary">
              <i class="fa fa-users fa-5x"></i><br><br>
			Students<br>Add,Edit and Manage Student
            <a href="#" class="btn btn-sq btn-primary">
              <i class="fa fa-briefcase fa-5x"></i><br><br>
           Job  Offers <br>Add,Edit and Manage Job Offer
            </a>
            <a href="#" class="btn btn-sq btn-primary">
<img src="https://icon-library.net//images/hand-shake-icon/hand-shake-icon-18.jpg">
<br><br>Internship Offers <br>Add,Edit and Manage Internship Offer
            </a>
			<a href="#" class="btn btn-sq btn-primary"><br><br>
              <i class="fa fa-th fa-5x"></i><br><br><br>
              Categories <br>Add,Edit and Manage Category
            </a>
            <a href="#" class="btn btn-sq btn-primary"><br><br>
              <i class="fa  fa-file-text-o fa-5x"></i><br/><br><br>
              Assessments<br>Add,Edit and Manage Assessment
            </a>
			   <a href="#" class="btn btn-sq btn-primary"><br><br>
              <i class="fa  fa-building fa-5x"></i><br/><br><br>
              Departments<br>Update Department Details and Team Members
            </a>
			   <a href="#" class="btn btn-sq btn-primary"><br><br>
              <i class="fa fa-bar-chart-o fa-5x"></i><br/><br><br>
              Reports<br>Reports
            </a>
          </p>
        </div>
	</div>
  
	<style>
	.btn-sq {
  width: 300px !important;
  height: 300px !important;
  font-size: 12px;
  float:left;
}
.fa-5x {
    font-size: 12em;
}
.btn-primary {
    color: #815ed6;
    background-color: white;
    border-color: white;
}
</style>