</br></br></br>
<div class="col-sm-12">
</br>
				
                        <header class="panel-heading">
                           Assessment
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Question ID</label>
                                    <input type="text" class="form-control" id="" placeholder="">
                                </div>
								
																<div class="form-group">
                                    <label for="">Company Name</label>
                                    <Select class="form-control" id="">
									<option value="" select>None</option>
									<option value="TCS">TCS</option>
									</select>
                                </div>
								
								<div class="form-group">
                                    <label for="">Question Type</label>
                                    <Select class="form-control" id="">
									<option value="" select>Logical Resoning</option>
									<option value="Quantitative">Quantative Aptitude</option>
									</select>
                                </div>
								
                                <div class="form-group">
                                    <label for="">Question</label>
                                    <input type="text" class="form-control" id="" placeholder="">
                                </div>
								 <div class="form-group">
                                    <label for="exampleInputPassword1">Options</label>
							        <input type="text" class="form-control" placeholder="option 1"><br>
                                    <input type="text" class="form-control" placeholder="option 2"><br>
                                    <input type="text" class="form-control" placeholder="option 3"><br>
                                    <input type="text" class="form-control" placeholder="option 4"><br>

                                  
									
                                </div>
								 <div class="form-group">
                                    <label for="">Correcr Answer</label>
                                   <Select class="form-control" id="">
									<option value="" select>1</option>
									<option value="Quantitative">2</option>
																		<option value="Quantitative">3</option>
									<option value="Quantitative">4</option>

									</select>
									
                                </div>



                                <button type="submit" class="btn btn-info">Submit</button>
                            </form>
                            </div>

                        </div>

			
			
					
					


<div class="table-agile-info">
<div class="panel panel-default">

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <thead>
          <tr>
            <th data-breakpoints="xs">ID</th>
            <th>Company_Name</th>
            <th>Question_Type</th>
            <th>Question</th>

			<th>Action</th>

          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
            <td>1</td>
            <td>TCS</td>
            <td>Logical Reasoning</td>
            <td>Synonym for Dislike</td>
            
  
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-edit'></td>
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-remove'></td>
          
    </div>
    <footer class="panel-footer">
      <div class="row">
        
        <div class="col-sm-7 text-right text-center-xs">                
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <li><a href=""><i class="fa fa-chevron-left"></i></a></li>
            <li><a href="">1</a></li>
            <li><a href="">2</a></li>
            <li><a href="">3</a></li>
            <li><a href="">4</a></li>
            <li><a href=""><i class="fa fa-chevron-right"></i></a></li>
          </ul>
        </div>
      </div>
    </footer>


            </div>
        </div>
</div>		