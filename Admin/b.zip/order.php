<br><br>
<div class="table-agile-info">
<div class="panel panel-default">

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <thead>
          <tr>
            <th data-breakpoints="xs"> Order ID</th>
            <th>Student Id</th>
			            <th>Student_Name</th>
						<th>Food_id</th>
			            <th>Food_Name</th>
			            <th>Food_Quantity</th>
			            <th>Food_Price</th>






			           

			<th>Action</th>

          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
            <td>1</td>
            <td>2</td>
            <td>abc</td>
			            <td>2</td>
						
			            <td>Dosa</td>
			            <td>3</td>
			            <td>Rs.25/-</td>

            

  
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-edit'></td>
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-remove'></td>
          
    </div>
	
   

            </div>
        </div>
</div>		