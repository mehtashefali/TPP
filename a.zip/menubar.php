<div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
						    <li>
                    <a class="active" href="Main.php">
                        <i class="fa fa-comment"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a class="active" href="Main.php?page=1">
                        <i class="fa fa-comment"></i>
                        <span>Messages</span>
                    </a>
                </li>
                
                <li class="sub-menu">
                    <a href="Main.php?page=2">
                        <i class="fa fa-book"></i>
                        <span>Assessments and Practice Test</span>
                    </a>
                    
                </li>
				
                 <li class="sub-menu">
                    <a href="Main.php?page=3">
                        <i class="fa fa-star"></i>
                        <span>Opportunities</span>
                    </a>
                    
                </li>
				 <li class="sub-menu">
                    <a href="Main.php?page=4">
                        <i class="fa fa-file"></i>
                        <span>Applications</span>
                    </a>
                    
                </li>
				 <li class="sub-menu">
                    <a href="Main.php?page=5">
                        <i class="fa fa-plus"></i>
                        <span>Offers</span>
                    </a>
                    
                </li>
                <li class="sub-menu">
                    <a href="Main.php?page=7">
                        <i class="fa fa-file"></i>
                        <span>Resumes</span>
                    </a>
	                
                 </li>

                   
                </li>
                <li>
                    <a href="index.php?Logout=Logout">
                        <i class="fa fa-user"></i>
                        <span>LogOut</span>
                    </a>
                </li>
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>